<div class="wrap p-t-0">
    <footer class="app-footer">
      
        <div class="copyright pull-left">Doctor Appointment Management System </div>
   
    </footer>
  </div>